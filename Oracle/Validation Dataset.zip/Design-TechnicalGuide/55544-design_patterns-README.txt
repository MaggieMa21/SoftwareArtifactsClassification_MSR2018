Design Patterns

- Observer